<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>분석 페이지</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        header h1 {
            color: green;
            font-size: 24px;
        }
        .logout-btn {
            background-color: #006400;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .logout-btn:hover {
            background-color: #004d00;
        }
        main {
            display: flex;
            justify-content: center;
        }
        .analysis-section {
            flex: 1;
            max-width: 800px;
            padding: 20px;
            border-radius: 10px;
            background: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .analysis-section h2 {
            margin-bottom: 20px;
            font-size: 20px;
            color: green;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background-color: #f2f2f2;
        }
        .progress-container {
            width: 100%;
            height: 20px;
            background: #eee;
            border-radius: 10px;
            overflow: hidden;
            margin: 10px 0;
            position: relative;
        }
        .progress-bar {
            height: 100%;
            background: #4caf50;
            width: 0;
        }
        .success-rate span {
            font-weight: bold;
            margin-bottom: 10px;
            display: block;
        }
        .detail-link, .list-link {
            text-decoration: none;
            color: #007bff;
        }
        .detail-link:hover, .list-link:hover {
            text-decoration: underline;
        }
        .back-btn {
            margin-top: 20px;
            display: block;
            background-color: #666666;
            color: white;
            text-align: center;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        .back-btn:hover {
            background-color: #444444;
        }
    </style>
</head>
<body>
    <header>
        <h1>(주) 영남대학교</h1>
        <a href="logout.php" class="logout-btn">로그아웃</a>
    </header>

    <main>
        <section class="analysis-section">
            <h2>분석 페이지</h2>

            <!-- 전체 프로젝트 성공률 -->
            <div class="success-rate">
                <?php
                // 데이터베이스 연결
                $conn = new mysqli('localhost', 'root', '', 'project_');
                if ($conn->connect_error) {
                    die("연결 실패: " . $conn->connect_error);
                }

                // 프로젝트 데이터 가져오기
                $project_sql = "
                    SELECT COUNT(*) AS total_projects,
                           SUM(CASE WHEN finish = 1 THEN 1 ELSE 0 END) AS completed_projects
                    FROM project
                ";
                $project_result = $conn->query($project_sql);
                $project_data = $project_result ? $project_result->fetch_assoc() : null;

                $total_projects = $project_data['total_projects'] ?? 0;
                $completed_projects = $project_data['completed_projects'] ?? 0;

                // 전체 프로젝트 성공률 계산
                $overall_success_rate = $total_projects > 0 ? round(($completed_projects / $total_projects) * 100, 2) : 0;
                ?>
                <span>전체 프로젝트 성공률</span>
                <div class="progress-container">
                    <div class="progress-bar" style="width: <?php echo $overall_success_rate; ?>%;"></div>
                </div>
                <span><?php echo $overall_success_rate; ?>%</span>
            </div>

            <!-- 프로젝트 진행도 테이블 -->
            <table>
                <thead>
                    <tr>
                        <th>프로젝트 이름</th>
                        <th>진행도</th>
                        <th>상세 보기</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // 프로젝트 목록 가져오기
                    $project_sql = "SELECT id, project_name, finish FROM project";
                    $project_result = $conn->query($project_sql);

                    if ($project_result && $project_result->num_rows > 0) {
                        while ($project_row = $project_result->fetch_assoc()) {
                            $project_id = $project_row['id'];
                            $project_name = htmlspecialchars($project_row['project_name']);

                            // task 테이블에서 진행률 계산
                            $task_sql = "
                                SELECT COUNT(*) AS total_tasks,
                                       SUM(CASE WHEN is_completed = 1 THEN 1 ELSE 0 END) AS completed_tasks
                                FROM task
                                WHERE project_id = $project_id
                            ";
                            $task_result = $conn->query($task_sql);
                            $task_data = $task_result ? $task_result->fetch_assoc() : ['total_tasks' => 0, 'completed_tasks' => 0];

                            $total_tasks = $task_data['total_tasks'];
                            $completed_tasks = $task_data['completed_tasks'];
                            $progress = $total_tasks > 0 ? round(($completed_tasks / $total_tasks) * 100, 2) : 0;

                            // 테이블 출력
                            echo "<tr>";
                            echo "<td>$project_name</td>";
                            echo "<td>$progress%</td>";
                            echo "<td><a href='analysis2.php?project_id=$project_id' class='detail-link'>상세 진행도 보기</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>프로젝트 데이터가 없습니다.</td></tr>";
                    }

                    // 데이터베이스 연결 종료
                    $conn->close();
                    ?>
                </tbody>
            </table>

            <!-- 뒤로가기 버튼 -->
            <a href="m_home.php" class="back-btn">뒤로가기</a>
        </section>
    </main>
</body>
</html>
