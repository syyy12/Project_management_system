<?php
session_start();
include 'db.php';

if (!isset($_SESSION['login_id']) || $_SESSION['role'] != 1) {
    header("Location: login.php");
    exit();
}

$userQuery = "SELECT login_id, user_name FROM user_view WHERE role != 1";
$userResult = $conn->query($userQuery);
$users = $userResult->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $projectName = trim($_POST['project_name']);
    $projectAdmins = $_POST['project_admins'] ?? [];
    $projectDescription = trim($_POST['project_description']);
    $projectStart = trim($_POST['project_start']);
    $projectEnd = trim($_POST['project_end']);
    $projectMembers = $_POST['project_members'] ?? [];

    if (strtotime($projectEnd) < strtotime($projectStart)) {
        $error = "종료일은 시작일 이후여야 합니다.";
    } elseif (!empty(array_diff($projectAdmins, $projectMembers))) {
        $error = "관리자는 반드시 프로젝트 멤버로 선택되어야 합니다.";
    } else {
        $projectInsertQuery = "INSERT INTO project (project_name, description, start, end, finish) VALUES (?, ?, ?, ?, 0)";
        $stmt = $conn->prepare($projectInsertQuery);
        $stmt->bind_param("ssss", $projectName, $projectDescription, $projectStart, $projectEnd);
        if (!$stmt->execute()) {
            die("프로젝트 삽입 실패: " . $stmt->error);
        }
        $projectId = $conn->insert_id;

        foreach ($projectAdmins as $adminId) {
            $adminInsertQuery = "INSERT INTO project_member (project_id, login_id, project_role) VALUES (?, ?, 1)";
            $adminStmt = $conn->prepare($adminInsertQuery);
            $adminStmt->bind_param("is", $projectId, $adminId);
            $adminStmt->execute();
        }

        foreach ($projectMembers as $memberId) {
            if (!in_array($memberId, $projectAdmins)) {
                $memberInsertQuery = "INSERT INTO project_member (project_id, login_id, project_role) VALUES (?, ?, 0)";
                $memberStmt = $conn->prepare($memberInsertQuery);
                $memberStmt->bind_param("is", $projectId, $memberId);
                $memberStmt->execute();
            }
        }

        header("Location: m_project.php?project_id=" . $projectId);
        exit();
    }
}
?>


<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>프로젝트 생성</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
        }
        h2 {
            text-align: center;
            color: #004d99;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea {
            height: 100px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>프로젝트 생성</h2>
        <form method="POST" action="m_create.php">
            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
            <label for="project_name">프로젝트 이름</label>
            <input type="text" id="project_name" name="project_name" placeholder="프로젝트 이름을 입력하세요" required>

            <label for="project_admins">프로젝트 관리자</label>
<select id="project_admins" name="project_admins[]" multiple required>
    <?php foreach ($users as $user): ?>
        <option value="<?php echo htmlspecialchars($user['login_id']); ?>">
            <?php echo htmlspecialchars($user['user_name']); ?>
        </option>
    <?php endforeach; ?>
</select>


            <label for="project_description">프로젝트 설명</label>
            <textarea id="project_description" name="project_description" placeholder="프로젝트 설명을 입력하세요"></textarea>

            <label for="project_start">프로젝트 시작일</label>
            <input type="date" id="project_start" name="project_start" required>

            <label for="project_end">프로젝트 종료일</label>
            <input type="date" id="project_end" name="project_end" required>

            <label for="project_members">프로젝트 진행 멤버</label>
            <select id="project_members" name="project_members[]" multiple required>
                <?php foreach ($users as $user): ?>
                    <option value="<?php echo htmlspecialchars($user['login_id']); ?>">
                        <?php echo htmlspecialchars($user['user_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">프로젝트 생성</button>
        </form>
    </div>
</body>
</html>